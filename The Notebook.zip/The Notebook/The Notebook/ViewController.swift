//
//  ViewController.swift
//  The Notebook
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import MapKit  // 1. Apple's Map Libaray

import CoreLocation




class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate{
    
    var mylocation : [CLLocationCoordinate2D] = []
    
    
    // MaRK - outlets
    @IBOutlet weak var mapView: MKMapView!
    
    
    @IBOutlet weak var labelMap: UILabel!
    
    // Make a coreLocation variable
    var manager : CLLocationManager!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1. Setup your CoreLocation variable
        self.manager = CLLocationManager()
        self.manager.delegate = self
    
        // 2. Tell ios how accurate you want the location to be
        self.manager.desiredAccuracy = kCLLocationAccuracyBest
        
        // 3. Ask the user for permission to get their location
        manager.requestAlwaysAuthorization()
        
        // 4. get the user's location
        self.manager.startUpdatingLocation()
        
        // UI nonsense - Setup the map to show their location
        mapView.delegate = self as! MKMapViewDelegate
        mapView.mapType = MKMapType.standard
        mapView.showsUserLocation = true
        
        
        
        /*
        // 1. COORDINATE:  set the position of the center of the map
        // CLLocationCoordinate
        // This is for fairview Mall
        let coord = CLLocationCoordinate2DMake(43.7779, 79.3447)
        
        // 2. SPAN: set the zoom level of the map
        // -MKCoordinateSpan
        // - Small numbers = GO IN (Closer)
        // - big numbers = GO OUT (far away)
        let span = MKCoordinateSpanMake(0.05, 0.05)
        
        // 3. Region: create a "region" object for the map
        //  - MKCoordinateRegion
        let region = MKCoordinateRegionMake(coord, span)
        
        // 4. do some nonsense to show thw map on the screen
        
        mapView.setRegion(region, animated: true)
        
    
*/
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // Mark - CoreLocation related function
    // ------------------------------------------------

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // 1. get the person's moost recent location
        // let i = locations.count - 1
         // labelMap.text = ("\(locations[i])")
        
        // 2. UI Nonsense: update the map to match the person's location
        
        // Polyline
        self.mylocation.append(mapView.userLocation.coordinate)
        if(self.mylocation.count>2)
        {
            print("Drawing Polylines")
            let polyline = MKPolyline(coordinates: self.mylocation, count: self.mylocation.count)
            self.mapView.add(polyline)
        }
        else {
            print("Not drawing polyline")
        }
        
        // coordinate - center of map location
        // Span - zoom level
        // region - nonsense
        
        let coord = mapView.userLocation.coordinate
        let span = MKCoordinateSpanMake(0.05, 0.05)
        let region = MKCoordinateRegionMake(coord, span)
        self.mapView.setRegion(region, animated: true)
        
    }
    
    // NONSENSE UI FUNCTION TO SHOW GAPHICS ON MAPS
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        // 4. show polyline on the map
        if(overlay is MKPolyline) {
            let r = MKPolylineRenderer(overlay: overlay)
            
            r.strokeColor = UIColor.red
            return r
        }
        return MKOverlayRenderer()
    }

}

