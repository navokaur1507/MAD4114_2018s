//
//  ViewController.swift
//  CoreData01
//
//  Created by MacStudent on 2018-07-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1. create variable that allows you to interact with
        // CoreData database
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        // 2. crteate a row in ther table
        
        // 2a. what table do i want tyo interact with? (User)
        let userEntity = NSEntityDescription.entity(forEntityName: "User", in: managedContext)!
        
        // 2b. make the row in the table
        
        //------- create a new User object
        let user = NSManagedObject(entity: userEntity, insertInto: managedContext)
        
        //----- set the properties of the object
        user.setValue("Jigesha", forKey: "name")
        user.setValue("Jigesha@gmail.com", forKey: "email")
        user.setValue(5, forKey: "kids")
        
        // make a date variable
        let formatter = DateFormatter()
        formatter.dateFormat="yyyy-MM-dd"
        let date = formatter.date(from:"2015-05-23")
        
        user.setValue(date, forKey: "birthday")
        
        print(user)
        
        // 3. save the row to the table
        do {
            
        try managedContext.save()
        }
        catch {
            print("PROBLEM SAVING TO DATABASE")
        
        }
        print("done saving to database")
        
        // 4. show --->--->
        
        // 4a. craete a SELECT * FROM USER command
        let userFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        
        // 4b. RUN THE SQL
        do {
            
          
        let users = try managedContext.fetch(userFetch)
            print(users)
        }
        catch {
            print("ERRO WHILE FETCHIUNG STUFF FROM DATABASE")
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

