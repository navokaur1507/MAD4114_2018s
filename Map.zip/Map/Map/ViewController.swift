//
//  ViewController.swift
//  Map
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.mapView.delegate = self  // b need this
        
        // setup map
        
        let coordinate = CLLocationCoordinate2DMake(31.7917, -7.0926)
        let span = MKCoordinateSpanMake(5, 5)
        let region = MKCoordinateRegion(center: coordinate, span: span)
        
        mapView.setRegion(region, animated: true)
        
        // Pollyline
        
        // 1. crete an array of location
        let b = [
            CLLocationCoordinate2DMake(31.6295, -7.9811),
            CLLocationCoordinate2DMake(33.5731, -7.5898)
            
        ]
        
        // 2. create a MKPollyline object and tell it about your location
        let polyline = MKPolyline(coordinates: b, count: b.count)
        
        // 3. Add it to the map
        self.mapView.add(polyline)
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // NONSENSE UI FUNCTION TO SHOW GAPHICS ON MAPS
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        // 4. show polyline on the map
        if(overlay is MKPolyline) {
        let r = MKPolylineRenderer(overlay: overlay)
        
        r.strokeColor = UIColor.red
        return r
    }
    return MKOverlayRenderer()
    }



    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
