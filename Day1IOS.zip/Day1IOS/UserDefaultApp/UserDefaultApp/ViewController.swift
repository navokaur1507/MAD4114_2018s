//
//  ViewController.swift
//  UserDefaultApp
//
//  Created by MacStudent on 2018-07-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // User Default
        // 1. tell ios you want to use UserDefaulta (localStroge from web)
        let defaults = UserDefaults.standard
        
        // show what is in the dictionary by default
        print(defaults.dictionaryRepresentation())
        
        // 2. add some things to UserDefaults
        
        // string
        defaults.set("Navjot",forKey:"myname");
        
        // boolean
        defaults.set(true, forKey:"isInstructor")
        
        // double
        defaults.set(800.59, forKey:"hourlyRate")
        
        // array
        let coursesTaught = ["ios 101", "andriod 101", "swift 101", "java 101", "database 101"]
        defaults.set(coursesTaught, forKey: "courses")
        
        // dictionary
        let student = ["name":"Vishavjeet Singh", "id":"c0701033", "program":"MADT", "sem":"third"]
        defaults.set(student, forKey:"student")
        
        // 3. print / get stuff from UserDefaults
        
        // print everything
        print(defaults.dictionaryRepresentation())
        
        // get a specific thing from the dictionary
        let x = defaults.double(forKey: "hourlyRate")
        print(x)
        
        print("is Navjot an Instructor?")
        print(defaults.bool(forKey: "isIntructor"))
        
        print("What's his full name?")
        let name = defaults.string(forKey: "myname")
        print(name!)
        
        print("What courses does he teach?")
        let c = defaults.array(forKey: "courses") as! [String]
        print(c)
        
        // get a dictionary out
        print("Who is his Student?")
        let d = defaults.dictionary(forKey: "student") as! Dictionary<String,String>
        print(d)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

