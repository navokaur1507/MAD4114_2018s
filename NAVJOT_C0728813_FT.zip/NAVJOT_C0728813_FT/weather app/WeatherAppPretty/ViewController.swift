//
//  ViewController.swift
//  WeatherAppPretty
//
//  Created by robin on 2018-07-15.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Alamofire            // 1. Import AlamoFire and SwiftyJson
import SwiftyJSON

import ChameleonFramework         // optional - used to make colors pretty

import CoreLocation               // TODO: Add location later


class ViewController: UIViewController, CLLocationManagerDelegate {

    
    // Make a CoreLocation variable
 let locationManager : CLLocationManager = CLLocationManager()
    
    // --------------------------------------------
    // MARK: User interface outlets
    // --------------------------------------------
    
    
    @IBOutlet weak var currency: UILabel!
    @IBOutlet weak var dailyPrice: UILabel!
    @IBOutlet weak var highestPrice: UILabel!
    @IBOutlet weak var lowestPrice: UILabel!
    @IBOutlet weak var avgPrice: UILabel!
    
    // TODO: Add location variables
    // --------------------------------------------
    
    // put your location variables here
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // UI NONSENSE - Make a gradient background using Chameleon
        let colors:[UIColor] = [
            UIColor(hexString:"#F27121")!,
            UIColor(hexString:"#E94057")!,
            UIColor(hexString:"#8A2387")!
        ]
        view.backgroundColor = UIColor(gradientStyle:UIGradientStyle.topToBottom, withFrame:view.frame, andColors:colors)
        
        
    func getCurrency(url:String) {
        // Build the URL:
        //let currency = Double(self.currency.text!)
        let url = "https://api.coindesk.com/v1/bpi/historical/close.json?start=2017-11-01&end=2018-02-12"
        print(url)
        
        
        
        Alamofire.request(url, method: .get, parameters: nil).responseJSON {
            
            (response) in
            
            if response.result.isSuccess {
                if let dataFromServer = response.data {
                    
        
                    do {
                        let json = try JSON(data: dataFromServer)
                        
                        // TODO: Parse the json response
                        print("=================")
                        //print(json)
                        
                        // TODO: Display the results
    
                        let price = json["bpi"].dictionaryValue
                        print(price)
            
                        for (key, value) in price{
                            print(key)
                            print("Price")
                            print("value")
                        }

                        
                        // do any math conversions (high,low,avg)
                        let dictkeyInc = price.sorted(by: <)
                        let dictkeyDec = price.sorted(by: >)
                        
                        print(dictkeyInc)
                        print(dictkeyDec)
                        
     
                    }
                    catch {
                        print("error")
                    }
                    
                }
                else {
                    print("Error when getting JSON from the response")
                }
            }
            else {
                // 6. You got an error while trying to connect to the API
                print("Error while fetching data from URL")
            }
            
        }
        

    }
    
    
    // --------------------------------------------
    // TODO: Add location
    // --------------------------------------------
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // this function gets called every time the person's location changes
        print("location updated!")
    
        // get the last location in the array
        let i = locations.count - 1;
        let location = locations[i]
        
        
    }
    

}

}
