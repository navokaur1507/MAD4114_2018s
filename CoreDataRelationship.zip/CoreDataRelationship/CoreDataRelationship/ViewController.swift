//
//  ViewController.swift
//  CoreDataRelationship
//
//  Created by MacStudent on 2018-07-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var tbNotebookName: UITextField!
    
    @IBOutlet weak var tbPage: UITextField!
    
    // create the context variable
    var mycontext:NSManagedObjectContext!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        // set the context
        mycontext = appDelegate.persistentContainer.viewContext
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // Mark: -- actions
    
    @IBAction func addNotebookPressed(_ sender: UIButton) {
        // TODO: Add notebook code goes here
        print("Add Notebook Button Pressed!")
        
        // VALIDATION
        // -- check if the textbook is empty
        let x = tbNotebookName.text!
        if (x.isEmpty) {
            print("give your notebook a name")
        }
        
        let notebook = Notebook(context: mycontext)
        notebook.title = ""
        notebook.dateCreated = Date()
        
        do{
            try mycontext.save()
            print("notebook saved")
        }
        catch {
            print("error saving to database")
        }
    }
    
    
    @IBAction func addPagePressed(_ sender: UIButton) {
        
        let page = Page(context: mycontext)
        page.text = tbPage.text!
        page.dateAdded = Date()
        
        // get the notebook that you want to add to
        let x = tbNotebookName.text!
        // Validation
        if(x.isEmpty){
            print("please enter the notebook name")
            return
        }
        let n = getNotebook(name: x)
        
        // Validation check the notebook exits
        if(n == nil)
        {
            print("this notebook does not exits")
            return
        }
        page.notebooks = n
        do {
            try mycontext?.save()
            print("saved")
        }
        catch {
            print("error saving to notebook")
        }
        
        // associate the page to notebook
        
        // page.notebook.n
    }
    
    /*
    public Notebook getNotebook(String name) {
    
     if (name == "navjot") {
     return
    }
    */
    
    func getNotebook(name:String) -> Notebook? {
        // 1. fetch the notebook with this name from Coredata
        let fetchRequest:NSFetchRequest<Notebook> = Notebook.fetchRequest()
        
        // 2. add a WHERE to my sql statement
        fetchRequest.predicate = NSPredicate(format: "name = %@", name)
        
        // 3. add a LIMIT
        fetchRequest.fetchLimit = 1
        
        // fetchRequest = SELECT * from Notebook where name = 'swift class' LIMIT !
        
        // 4. get the results from the database
        do {
            let rows = try mycontext.fetch(fetchRequest)
            
            if (rows.count > 0) {
                print(rows[0].title )
                return rows[0]
            }
            else {
                // no notebook found that have this name
                return nil
            }
        }
        catch  {
            print("error getting from the database")
        }
        // Return it
        return nil
    }
    
    
    @IBAction func showAllPages(_ sender: UIButton) {
        
        // get the name of the notebook
        let x = tbNotebookName.text!
        // Validation
        // Check that person put something into the text box
        if(x.isEmpty){
            print("please enter the notebook name")
            return
        }
        let n = getNotebook(name: x)
        // query database
        // a) make a fetch request
        let fetchRequest:NSFetchRequest<Page> = Page.fetchRequest()
        
        // 2. add a WHERE to my sql statement
        fetchRequest.predicate = NSPredicate(format: "notebook = %@", n!)
        do {
            let rows = try mycontext.fetch(fetchRequest)
            
            for rows in rows {
                print(rows.text!)
                print(rows.dateAdded!)
                print("=========")
            }
           
        }
        catch  {
            print("error getting from the database")
        }
    
    }
    
}

